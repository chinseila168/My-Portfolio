const CardLeft = () => {
  return <div>Card Left</div>;
};

export default CardLeft;
